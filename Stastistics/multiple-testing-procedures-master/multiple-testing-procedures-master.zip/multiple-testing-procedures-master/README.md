# multiple-testing-procedures
Algorithms for multiple testing procedures (i.e. corrections for multiple comparisons) and code to estimate the performance of each procedure
